<?
$arModuleVersion = array("VERSION" => "2.1.13", "VERSION_DATE" => "2021-08-19 12:00:00");?>