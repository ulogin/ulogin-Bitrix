<?php
$updater->CopyFiles("install/components/ulogin/auth/include/Ulogin.class.php", "components/ulogin/auth/include/Ulogin.class.php");
$updater->CopyFiles("install/components/ulogin/sync/include/UloginSync.class.php", "components/ulogin/sync/include/UloginSync.class.php");
$updater->CopyFiles("install/components/ulogin/auth/include/functions.php", "components/ulogin/auth/include/functions.php");