<?
$arModuleVersion = array("VERSION" => "2.0.4", "VERSION_DATE" => "2015-11-02 15:00:00");?>