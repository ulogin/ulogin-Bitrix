<?
$arModuleVersion = array("VERSION" => "2.1.11", "VERSION_DATE" => "2016-07-25 12:00:00");?>