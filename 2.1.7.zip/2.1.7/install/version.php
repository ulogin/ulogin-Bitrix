<?
$arModuleVersion = array("VERSION" => "2.1.7", "VERSION_DATE" => "2016-03-18 13:30:00");?>