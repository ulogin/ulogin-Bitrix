<?php
$updater->CopyFiles("install/components/ulogin/auth/include/Ulogin.class.php", "components/ulogin/auth/include/Ulogin.class.php");