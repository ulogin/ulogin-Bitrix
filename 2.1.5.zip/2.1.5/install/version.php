<?
$arModuleVersion = array("VERSION" => "2.1.5", "VERSION_DATE" => "2016-03-17 12:15:00");?>