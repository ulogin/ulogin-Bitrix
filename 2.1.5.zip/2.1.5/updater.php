<?php
$updater->CopyFiles("install/components/ulogin/auth/component.php", "components/ulogin/auth/component.php");
$updater->CopyFiles("install/components/ulogin/auth/include/Ulogin.class.php", "components/ulogin/auth/include/Ulogin.class.php");
$updater->CopyFiles("install/components/ulogin/sync/component.php", "components/ulogin/sync/component.php");
$updater->CopyFiles("install/components/ulogin/sync/ulogin-ajax.php", "components/ulogin/sync/ulogin-ajax.php");