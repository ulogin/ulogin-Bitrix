<?
$arModuleVersion = array("VERSION" => "2.1.4", "VERSION_DATE" => "2016-03-17 11:35:00");?>