<?
$arModuleVersion = array("VERSION" => "2.0.7", "VERSION_DATE" => "2015-11-02 16:40:00");?>