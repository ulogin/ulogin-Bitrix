<?
$arModuleVersion = array("VERSION" => "2.0.3", "VERSION_DATE" => "2015-11-02 11:00:00");?>