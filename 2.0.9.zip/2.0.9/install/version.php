<?
$arModuleVersion = array("VERSION" => "2.0.9", "VERSION_DATE" => "2015-12-10 14:00:00");?>