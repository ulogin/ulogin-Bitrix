<?
$arModuleVersion = array("VERSION" => "2.1.12", "VERSION_DATE" => "2016-11-28 11:30:00");?>