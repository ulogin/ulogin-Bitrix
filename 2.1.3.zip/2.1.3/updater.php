<?php
$updater->CopyFiles("install/components/ulogin/auth/component.php", "components/ulogin/auth/component.php");