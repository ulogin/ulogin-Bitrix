<?php
$updater->CopyFiles("install/components/ulogin/auth/lang/ru/.parameters.php", "components/ulogin/auth/lang/ru/.parameters.php");
$updater->CopyFiles("install/components/ulogin/auth/.parameters.php", "components/ulogin/auth/.parameters.php");