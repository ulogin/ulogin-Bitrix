<?
$arModuleVersion = array("VERSION" => "2.1.10", "VERSION_DATE" => "2016-06-08 14:00:00");?>