<?
$arModuleVersion = array("VERSION" => "2.1.2", "VERSION_DATE" => "2016-03-16 12:20:00");?>