<?php
$updater->CopyFiles("install/components/ulogin/auth/component.php", "components/ulogin/auth/component.php");
$updater->CopyFiles("install/components/ulogin/sync/component.php", "components/ulogin/sync/component.php");