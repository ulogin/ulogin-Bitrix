<?
$arModuleVersion = array("VERSION" => "2.1.9", "VERSION_DATE" => "2016-05-06 15:30:00");?>