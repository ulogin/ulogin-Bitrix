<?
$arModuleVersion = array("VERSION" => "2.1.6", "VERSION_DATE" => "2016-03-18 13:15:00");?>