<?
$arModuleVersion = array("VERSION" => "2.0.8", "VERSION_DATE" => "2015-12-08 14:50:00");?>