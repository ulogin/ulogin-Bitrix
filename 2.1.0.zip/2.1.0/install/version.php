<?
$arModuleVersion = array("VERSION" => "2.1.0", "VERSION_DATE" => "2015-12-11 12:00:00");?>