<?php
$updater->CopyFiles("install/components/ulogin/auth/.parameters.php", "components/ulogin/auth/.parameters.php");
$updater->CopyFiles("install/components/ulogin/auth/include/Ulogin.class.php", "components/ulogin/auth/include/Ulogin.class.php");
$updater->CopyFiles("install/components/ulogin/auth/lang/ru/.parameters.php", "components/ulogin/auth/lang/ru/.parameters.php");